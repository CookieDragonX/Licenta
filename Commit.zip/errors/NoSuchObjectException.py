class NoSuchObjectException(Exception):
    "Cookie attempted to load a non existing object..."
    pass