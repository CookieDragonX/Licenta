from Object import Object

def loadTree(metaData):


# Tree --> map{string, Tree|Blob}

class Tree(Object):
    def __init__(self) -> None:
        super().__init__()
        pass